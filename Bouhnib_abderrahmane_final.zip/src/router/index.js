import { createRouter, createWebHistory } from "vue-router";

import HomeView from "../pages/indexPage.vue";
import ServiceDetail from "../pages/services/servicesPage.vue";
import ServiceSlots from "../pages/services/slotsPage.vue";
import BookingPage from "../pages/bookPage";
import NotFound from "../pages/404Page.vue";

const routes = [
  {
    path: "/",
    name: "home",
    component: HomeView,
  },
  {
    path: "/services/servicesPage/:id",
    name: "service-detail",
    component: ServiceDetail,
  },
  {
    path: "/services/:id/slots",
    name: "service-slots",
    component: ServiceSlots,
  },
  {
    path: "/book/:slotId",
    name: "booking",
    component: BookingPage,
  },
  {
    path: "/:pathMatch(.*)*",
    name: "not-found",
    component: NotFound,
  },
];

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes,
});

export default router;
