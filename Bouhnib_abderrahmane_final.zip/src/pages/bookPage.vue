<template>
  <div v-if="slot">
    <h1>Réserver : {{ formattedDate }}</h1>
    <BookingForm @submit="handleSubmit" :isBooked="slot.isBooked" />
  </div>
  <div v-else>
    <p>Créneau introuvable.</p>
  </div>
</template>

<script setup>
import { ref, onMounted, computed } from "vue";
import { useRoute, useRouter } from "vue-router";
import fakedb from "../../fakedb.js";
import BookingForm from "../components/BookingForm.vue";

const route = useRoute();
const router = useRouter();
const slot = ref(null);

onMounted(async () => {
  slot.value = await fakedb.getSlotById(route.params.slotId);
});

const formattedDate = computed(() => {
  if (!slot.value) return "";
  return new Date(slot.value.dateTime).toLocaleString("fr-FR", {
    dateStyle: "full",
    timeStyle: "short",
  });
});

async function handleSubmit(bookingDetails) {
  if (!slot.value) return;

  if (slot.value.isBooked) {
    alert("Ce créneau est déjà réservé.");
    return;
  }

  const response = await fakedb.bookSlot(slot.value.id, bookingDetails);
  if (response.success) {
    alert(response.message);
    router.push("/");
  } else {
    alert("Erreur : " + response.message);
  }
}
</script>
