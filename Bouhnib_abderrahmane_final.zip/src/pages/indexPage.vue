<template>
  <div>
    <h1>Liste des services</h1>
    <ServiceCard
      v-for="service in services"
      :key="service.id"
      :service="service"
    />
  </div>
</template>

<script setup>
import { ref, onMounted } from "vue";
import fakedb from "../../fakedb.js";
import ServiceCard from "../components/ServiceCard.vue";

const services = ref([]);

onMounted(async () => {
  services.value = await fakedb.getAllServices();
});
</script>
