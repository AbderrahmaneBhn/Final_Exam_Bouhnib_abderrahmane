<template>
  <div>
    <h1>404 - Page non trouvée</h1>
    <router-link to="/">Retour à l'accueil</router-link>
  </div>
</template>
