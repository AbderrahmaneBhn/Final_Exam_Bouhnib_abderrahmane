<template>
  <div v-if="service">
    <h1>{{ service.name }}</h1>
    <p>{{ service.description }}</p>
    <p>
      <small>Durée : {{ service.duration }} min</small>
    </p>
    <router-link :to="`/services/${service.id}/slots`">
      <button>Voir les créneaux disponibles</button>
    </router-link>
  </div>
  <div v-else>
    <p>Service introuvable.</p>
  </div>
</template>

<script setup>
import { ref, onMounted } from "vue";
import { useRoute } from "vue-router";
import fakedb from "../../../fakedb.js";

const route = useRoute();
const service = ref(null);

onMounted(async () => {
  service.value = await fakedb.getServiceById(route.params.id);
});
</script>
