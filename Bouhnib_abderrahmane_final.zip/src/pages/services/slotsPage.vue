<template>
  <div>
    <h1>Créneaux pour {{ serviceName }}</h1>
    <div v-if="slots.length">
      <!-- <SlotItem v-for="slot in slots" :key="slot.id" :slot="slot" /> -->
    </div>
    <div v-else>
      <p>Aucun créneau disponible.</p>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from "vue";
import { useRoute } from "vue-router";
import fakedb from "../../../fakedb.js";
// import SlotItem from "../../components/SlotItem.vue";

const route = useRoute();
const slots = ref([]);
const serviceName = ref("");

onMounted(async () => {
  const service = await fakedb.getServiceById(route.params.id);
  serviceName.value = service ? service.name : "Service inconnu";
  slots.value = await fakedb.getSlotsByService(route.params.id);
});
</script>
