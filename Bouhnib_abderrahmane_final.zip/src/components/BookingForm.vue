<template>
  <form @submit.prevent="submitBooking">
    <div>
      <label for="name">Nom :</label>
      <input id="name" v-model="form.name" required />
    </div>
    <div>
      <label for="email">Email :</label>
      <input id="email" type="email" v-model="form.email" required />
    </div>
    <button type="submit">Confirmer la réservation</button>
  </form>
</template>

<script setup>
import { ref, defineEmits } from "vue";

const emit = defineEmits(["submit"]);

const form = ref({
  name: "",
  email: "",
});

const submitBooking = () => {
  emit("submit", form.value);
};
</script>

<style scoped>
form {
  display: flex;
  flex-direction: column;
  gap: 1rem;
}
</style>
