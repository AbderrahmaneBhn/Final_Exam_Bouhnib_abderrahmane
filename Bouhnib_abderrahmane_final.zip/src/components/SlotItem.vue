<template>
  <div class="slot-item">
    <p><strong>Date:</strong> {{ slot.date }}</p>
    <p><strong>Heure:</strong> {{ slot.time }}</p>
    <button :disabled="slot.isBooked" @click="goToBooking">
      {{ slot.isBooked ? "Déjà réservé" : "Réserver" }}
    </button>
  </div>
</template>

<script setup>
import { useRouter } from "vue-router";
import { defineProps } from "vue";

const props = defineProps({
  slot: {
    type: Object,
    required: true,
  },
});

const router = useRouter();

const goToBooking = () => {
  router.push(`/book/${props.slot.id}`);
};
</script>

<style scoped>
.slot-item {
  border: 1px solid #ddd;
  padding: 1rem;
  margin-bottom: 1rem;
}
button[disabled] {
  background-color: #ccc;
  cursor: not-allowed;
}
</style>
