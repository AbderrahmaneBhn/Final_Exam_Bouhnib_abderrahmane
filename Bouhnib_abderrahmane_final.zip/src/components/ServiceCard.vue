<template>
  <div class="service-card">
    <h2>{{ service.name }}</h2>
    <p>{{ service.description }}</p>
    <router-link :to="`/services/servicesPage/${service.id}`">
      <button>Voir les détails</button>
    </router-link>
  </div>
</template>

<script setup>
import { defineProps } from "vue";
defineProps({
  service: {
    type: Object,
    required: true,
  },
});
</script>

<style scoped>
.service-card {
  border: 1px solid #ccc;
  padding: 1rem;
  margin-bottom: 1rem;
}
</style>
